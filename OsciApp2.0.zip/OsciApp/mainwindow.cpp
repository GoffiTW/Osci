#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "oscilloscopeform.h"  // заголовочный файл с объявлениями функций DLL (не показан, но подразумевается)

// Внешние функции из main.cpp для доступа к данным
extern QVector<double>& getDataBuffer();
extern int getTotalPoints();
extern int getStepMs();

// Конструктор: настройка UI и соединение сигналов кнопок со слотами
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);   // инициализация формы из .ui

    // Привязка кнопок к слотам
    connect(ui->btnCreateOsc, &QPushButton::clicked, this, &MainWindow::onCreateOscilloscope);
    connect(ui->btnSendData, &QPushButton::clicked, this, &MainWindow::onSendData);
    connect(ui->btnGetOptions, &QPushButton::clicked, this, &MainWindow::onGetOptions);
    connect(ui->btnSetOptions, &QPushButton::clicked, this, &MainWindow::onSetOptions);

    // Вывод статуса: сколько точек сгенерировано
    ui->lblStatus->setText(QString("Данные сгенерированы: %1 точек").arg(getTotalPoints()));
}

// Деструктор
MainWindow::~MainWindow()
{
    delete ui;
}

// Создание осциллографа (вызов функции из DLL)
void MainWindow::onCreateOscilloscope()
{
    // Считываем значения из полей ввода
    int dPos = ui->spinDPos->value();
    int dNeg = ui->spinDNeg->value();
    int acpShift = ui->spinAcpShift->value();
    // Вызов внешней функции (предположительно объявлена в oscilloscopeform.h)
    CreateOscilloscope(dPos, dNeg, acpShift, 100, 100, 800, 600);
    ui->lblStatus->setText("Осциллограф создан");
}

// Отправка сгенерированных данных в осциллограф
void MainWindow::onSendData()
{
    QVector<double>& data = getDataBuffer();
    if (data.isEmpty()) {
        QMessageBox::warning(this, "Предупреждение", "Нет данных для отправки");
        return;
    }
    // Вызов внешней функции SendData (размер, указатель на массив, шаг в мс)
    SendData(data.size(), data.data(), getStepMs());
    ui->lblStatus->setText(QString("Данные отправлены: %1 точек, шаг %2 мс")
                               .arg(data.size()).arg(getStepMs()));
}

// Получение текущих настроек канала из DLL и отображение их в полях
void MainWindow::onGetOptions()
{
    int dPos, dNeg, acpShift;
    GetChannelOptions(dPos, dNeg, acpShift); // внешняя функция
    // Обновляем значения в спин-боксах
    ui->spinDPos->setValue(dPos);
    ui->spinDNeg->setValue(dNeg);
    ui->spinAcpShift->setValue(acpShift);
    // Показываем их также в информационном окне
    QString message = QString("DPos: %1\nDNeg: %2\nAcpShift: %3")
                          .arg(dPos).arg(dNeg).arg(acpShift);
    QMessageBox::information(this, "Channel Options", message);
    ui->lblStatus->setText("Настройки получены из DLL");
}

// Установка настроек канала (передаём в DLL значения из полей)
void MainWindow::onSetOptions()
{
    int dPos = ui->spinDPos->value();
    int dNeg = ui->spinDNeg->value();
    int acpShift = ui->spinAcpShift->value();
    SetOptions(dPos, dNeg, acpShift); // внешняя функция
    ui->lblStatus->setText(QString("Настройки отправлены в DLL: DPos=%1, DNeg=%2, AcpShift=%3")
                               .arg(dPos).arg(dNeg).arg(acpShift));
}