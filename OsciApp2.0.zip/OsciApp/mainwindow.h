#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

// Предварительное объявление класса Ui::MainWindow (сгенерирован из .ui файла)
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

// Класс главного окна, наследуется от QMainWindow
class MainWindow : public QMainWindow
{
    Q_OBJECT   // макрос для поддержки сигналов/слотов

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Слоты, связанные с кнопками интерфейса
    void onCreateOscilloscope();   // создание окна осциллографа
    void onSendData();             // отправка данных в осциллограф
    void onGetOptions();           // получение настроек канала из DLL
    void onSetOptions();           // установка настроек канала в DLL

private:
    Ui::MainWindow *ui;            // указатель на форму (содержит все виджеты)
};

#endif // MAINWINDOW_H