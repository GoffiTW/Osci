#include <QApplication>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include "mainwindow.h"

// Статический буфер для данных
static QVector<double> g_dataBuffer;
static int TOTAL_POINTS = 0;          // фактическое количество сгенерированных точек
static const int MAX_POINTS = 2000;   // максимально возможное количество точек
static const int STEP_MS = 10;        // шаг дискретизации (мс)
static bool dataGenerated = false;    // флаг, что данные уже созданы

// Функция генерации случайного шума в диапазоне [-5; 5]
double noise() {
    return (rand() % 11) - 5;
}

// Генерация "пакета" данных на основе последовательности битов
// Каждому биту соответствует уровень сигнала (+amplitude для 1, -amplitude для 0)
// samplesPerBit – количество отсчётов на один бит
void generatePacket(QVector<double>& buffer, double amplitude, const QVector<int>& bits, int samplesPerBit) {
    for (int bit : bits) {
        double level = (bit == 1) ? amplitude : -amplitude;
        for (int j = 0; j < samplesPerBit; ++j) {
            buffer.append(level + noise() * 0.5); // добавляем небольшую помеху
        }
    }
}

// Основная функция генерации тестового сигнала
void generateData()
{
    if (dataGenerated) return; // повторно не генерируем
    srand(static_cast<unsigned>(time(nullptr))); // инициализация ГСЧ

    // Случайное количество точек от 500 до MAX_POINTS
    TOTAL_POINTS = 500 + rand() % (MAX_POINTS - 500 + 1);
    g_dataBuffer.clear();
    g_dataBuffer.reserve(TOTAL_POINTS);

    // 1) Начальный шумовой фрагмент (50–150 точек)
    int initialNoise = 50 + rand() % 100;
    for (int i = 0; i < initialNoise && g_dataBuffer.size() < TOTAL_POINTS; ++i) {
        g_dataBuffer.append(noise());
    }

    // 2) Пакет полезного сигнала (от 10 до 30 битов)
    int numBits = 10 + rand() % 21;
    QVector<int> bits;
    for (int i = 0; i < numBits; ++i) bits.append(rand() % 2);
    int samplesPerBit = 10;
    double signalAmplitude = 20.0;
    generatePacket(g_dataBuffer, signalAmplitude, bits, samplesPerBit);

    // 3) Оставшееся место заполняем шумом (если не хватило – урезаем)
    if (g_dataBuffer.size() < TOTAL_POINTS) {
        int remaining = TOTAL_POINTS - g_dataBuffer.size();
        for (int i = 0; i < remaining; ++i) g_dataBuffer.append(noise());
    } else {
        g_dataBuffer.resize(TOTAL_POINTS);
    }

    dataGenerated = true;
}

// Глобальные функции доступа к данным (используются в mainwindow.cpp)
QVector<double>& getDataBuffer() { return g_dataBuffer; }
int getTotalPoints() { return TOTAL_POINTS; }
int getStepMs() { return STEP_MS; }

// Точка входа в приложение
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    generateData();           // создаём тестовый сигнал
    MainWindow w;             // создаём главное окно
    w.show();                 // показываем окно
    return a.exec();          // запускаем цикл обработки событий Qt
}