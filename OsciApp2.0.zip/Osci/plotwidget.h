#ifndef PLOTWIDGET_H
#define PLOTWIDGET_H

#include <QWidget>
#include <QVector>

// Виджет, рисующий осциллограмму с возможностью масштабирования,
// перетаскивания опорных линий DPos/DNeg и прокрутки.
class PlotWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PlotWidget(QWidget *parent = nullptr);

    // Установка данных и шага дискретизации (мс)
    void setData(const QVector<double>& data, int stepMs);
    void setStepMs(int stepMs);

    // Настройки канала
    void setDpos(int dpos);
    void setDneg(int dneg);
    void setAcpShift(int shift);

    // Масштабы: вертикальный (амплитуда) и горизонтальный (сжатие/растяжение по времени)
    void setVertScale(double scale);
    void setHorizScale(double scale);

    // Прокрутка: начальный индекс отображаемой области
    void setStartIndex(int index);

    // Геттеры
    int getDpos() const          { return m_dpos; }
    int getDneg() const          { return m_dneg; }
    int getAcpShift() const      { return m_acpShift; }
    double getVertScale() const  { return m_vertScale; }
    double getHorizScale() const { return m_horizScale; }
    int getStartIndex() const    { return m_startIndex; }
    int getTotalPoints() const   { return m_data.size(); }
    int getVisiblePoints() const;   // сколько точек помещается по горизонтали с учётом масштаба

signals:
    // Сигнал об изменении любых параметров, влияющих на отображение
    void paramsChanged();

protected:
    void paintEvent(QPaintEvent *event) override;   // отрисовка графика
    void mousePressEvent(QMouseEvent *event) override;   // начало перетаскивания линий
    void mouseMoveEvent(QMouseEvent *event) override;    // перемещение мыши с зажатой кнопкой
    void mouseReleaseEvent(QMouseEvent *event) override; // отпускание кнопки

private:
    QVector<double> m_data;       // массив амплитудных значений
    int m_stepMs = 1;             // шаг по времени (мс)
    int m_dpos = 0;               // уровень верхней опорной линии
    int m_dneg = 0;               // уровень нижней опорной линии
    int m_acpShift = 0;           // сдвиг всей кривой по вертикали
    double m_vertScale = 1.0;     // вертикальный масштаб (усиление)
    double m_horizScale = 1.0;    // горизонтальный масштаб: 1.0 – все точки помещаются в ширину, >1 – растяжение
    int m_startIndex = 0;         // индекс первой отображаемой точки

    // Состояние перетаскивания опорных линий мышью
    enum DragMode { NoDrag, DragDPos, DragDNeg };
    DragMode m_dragMode = NoDrag;
    int m_dragStartY = 0;         // начальная Y-координата мыши
    double m_originalValue = 0;   // исходное значение параметра (DPos или DNeg) до перетаскивания

    // Вспомогательные методы
    QRect getPlotRect() const;                     // область, где рисуется график (с отступами)
    double transformX(int index) const;            // преобразование индекса точки в X-координату
    double transformY(double value, double yMin, double yMax) const; // значение -> Y
    void computeYRange(double &yMin, double &yMax) const; // вычисление диапазона Y для текущего видимого участка
    double yToValue(int y, double yMin, double yMax) const; // Y -> значение
    int valueToY(double value, double yMin, double yMax) const; // значение -> Y
};

#endif // PLOTWIDGET_H