#include "oscilloscopeform.h"
#include "plotwidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QScrollBar>
#include <QPushButton>
#include <QLabel>

// Статический указатель на единственный экземпляр осциллографа (один на приложение)
static OscilloscopeForm* g_oscilloscope = nullptr;

// ========== Экспортируемые C-функции (точки входа для внешнего кода) ==========
extern "C" {

OSCILLOSCOPE_EXPORT void CreateOscilloscope(int DPos, int DNeg, int AcpShift,
                                            int Left, int Top, int Width, int Height)
{
    // Удаляем предыдущий экземпляр, если есть
    if (g_oscilloscope) {
        delete g_oscilloscope;
        g_oscilloscope = nullptr;
    }
    // Создаём новую форму
    g_oscilloscope = new OscilloscopeForm(nullptr, DPos, DNeg, AcpShift);
    // Устанавливаем позицию и размер
    g_oscilloscope->setGeometry(Left, Top, Width, Height);
    g_oscilloscope->show();   // отображаем окно
}

OSCILLOSCOPE_EXPORT void SendData(int NumberOfPoints, double* Bufer, int Step)
{
    if (!g_oscilloscope) return;
    // Копируем переданные данные в QVector
    QVector<double> data(Bufer, Bufer + NumberOfPoints);
    g_oscilloscope->sendData(data, Step);
}

OSCILLOSCOPE_EXPORT void GetChannelOptions(int& DPos, int& DNeg, int& AcpShift)
{
    if (g_oscilloscope)
        g_oscilloscope->getOptions(DPos, DNeg, AcpShift);
}

OSCILLOSCOPE_EXPORT void SetOptions(int DPos, int DNeg, int AcpShift)
{
    if (g_oscilloscope)
        g_oscilloscope->setOptions(DPos, DNeg, AcpShift);
}

} // extern "C"

// Конструктор класса OscilloscopeForm
OscilloscopeForm::OscilloscopeForm(QWidget *parent, int initDPos, int initDNeg, int initAcpShift)
    : QWidget(parent)
{
    // Создаём виджет графика
    m_plotWidget = new PlotWidget(this);
    // Горизонтальный скроллбар для прокрутки по времени
    m_scrollBar = new QScrollBar(Qt::Horizontal, this);
    m_scrollBar->setRange(0, 0); // пока данных нет, диапазон нулевой

    // Кнопки горизонтального масштабирования
    m_btnHorizZoomIn  = new QPushButton("H+", this);
    m_btnHorizZoomOut = new QPushButton("H-", this);

    // Кнопки для регулировки DPos, DNeg, AcpShift
    m_btnDPosInc = new QPushButton("DPos+", this);
    m_btnDPosDec = new QPushButton("DPos-", this);
    m_btnDNegInc = new QPushButton("DNeg+", this);
    m_btnDNegDec = new QPushButton("DNeg-", this);
    m_btnAcpInc  = new QPushButton("Shift+", this);
    m_btnAcpDec  = new QPushButton("Shift-", this);

    // Текстовые метки для отображения текущих значений
    m_lblDPos      = new QLabel(this);
    m_lblDNeg      = new QLabel(this);
    m_lblAcpShift  = new QLabel(this);
    m_lblVertScale = new QLabel(this);
    m_lblHorizScale= new QLabel(this);

    // Устанавливаем начальные параметры
    setOptions(initDPos, initDNeg, initAcpShift);
    m_plotWidget->setVertScale(1.0);
    m_plotWidget->setHorizScale(1.0);
    updateUIFromParams();   // обновить надписи

    // ---- Компоновка интерфейса (вертикальная) ----
    // Строка кнопок масштаба
    QHBoxLayout *zoomLayout = new QHBoxLayout;
    zoomLayout->addWidget(m_btnHorizZoomOut);
    zoomLayout->addWidget(m_btnHorizZoomIn);

    // Сетка для кнопок и отображения параметров
    QGridLayout *paramLayout = new QGridLayout;
    paramLayout->addWidget(new QLabel("DPos:"), 0, 0);
    paramLayout->addWidget(m_lblDPos, 0, 1);
    paramLayout->addWidget(m_btnDPosDec, 0, 2);
    paramLayout->addWidget(m_btnDPosInc, 0, 3);
    paramLayout->addWidget(new QLabel("DNeg:"), 1, 0);
    paramLayout->addWidget(m_lblDNeg, 1, 1);
    paramLayout->addWidget(m_btnDNegDec, 1, 2);
    paramLayout->addWidget(m_btnDNegInc, 1, 3);
    paramLayout->addWidget(new QLabel("AcpShift:"), 2, 0);
    paramLayout->addWidget(m_lblAcpShift, 2, 1);
    paramLayout->addWidget(m_btnAcpDec, 2, 2);
    paramLayout->addWidget(m_btnAcpInc, 2, 3);

    // Метки для текущих масштабов
    QHBoxLayout *scaleLabels = new QHBoxLayout;
    scaleLabels->addWidget(m_lblVertScale);
    scaleLabels->addWidget(m_lblHorizScale);

    // Основной вертикальный layout
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(m_plotWidget, 1);   // график занимает всё свободное место
    mainLayout->addWidget(m_scrollBar);
    mainLayout->addLayout(zoomLayout);
    mainLayout->addLayout(paramLayout);
    mainLayout->addLayout(scaleLabels);

    // ---- Соединение сигналов со слотами ----
    connect(m_btnHorizZoomIn,  &QPushButton::clicked, this, &OscilloscopeForm::onHorizZoomIn);
    connect(m_btnHorizZoomOut, &QPushButton::clicked, this, &OscilloscopeForm::onHorizZoomOut);
    connect(m_btnDPosInc,       &QPushButton::clicked, this, &OscilloscopeForm::onDPosInc);
    connect(m_btnDPosDec,       &QPushButton::clicked, this, &OscilloscopeForm::onDPosDec);
    connect(m_btnDNegInc,       &QPushButton::clicked, this, &OscilloscopeForm::onDNegInc);
    connect(m_btnDNegDec,       &QPushButton::clicked, this, &OscilloscopeForm::onDNegDec);
    connect(m_btnAcpInc,        &QPushButton::clicked, this, &OscilloscopeForm::onAcpShiftInc);
    connect(m_btnAcpDec,        &QPushButton::clicked, this, &OscilloscopeForm::onAcpShiftDec);
    connect(m_scrollBar,        &QScrollBar::valueChanged, this, &OscilloscopeForm::onScrollChanged);

    // Когда в PlotWidget меняются параметры (данные, масштаб и т.д.), обновляем UI и скролл
    connect(m_plotWidget, &PlotWidget::paramsChanged, this, &OscilloscopeForm::updateUIFromParams);
    connect(m_plotWidget, &PlotWidget::paramsChanged, [this]() {
        int total   = m_plotWidget->getTotalPoints();
        int visible = m_plotWidget->getVisiblePoints();
        if (total > visible) {
            m_scrollBar->setRange(0, total - visible);
            m_scrollBar->setPageStep(visible / 2);  // шаг при клике на область полосы
        } else {
            m_scrollBar->setRange(0, 0);
        }
        m_scrollBar->setValue(m_plotWidget->getStartIndex());
    });
}

OscilloscopeForm::~OscilloscopeForm() {}

// Передать новые данные в виджет графика
void OscilloscopeForm::sendData(const QVector<double>& data, int stepMs)
{
    if (m_plotWidget) {
        m_plotWidget->setData(data, stepMs);
    }
}

// Получить текущие настройки канала
void OscilloscopeForm::getOptions(int &dPos, int &dNeg, int &acpShift) const
{
    dPos     = m_plotWidget->getDpos();
    dNeg     = m_plotWidget->getDneg();
    acpShift = m_plotWidget->getAcpShift();
}

// Установить настройки канала
void OscilloscopeForm::setOptions(int dPos, int dNeg, int acpShift)
{
    m_plotWidget->setDpos(dPos);
    m_plotWidget->setDneg(dNeg);
    m_plotWidget->setAcpShift(acpShift);
    updateUIFromParams();
}

// ---- Обработчики кнопок ----
void OscilloscopeForm::onHorizZoomIn()
{
    // Увеличиваем горизонтальный масштаб в 1.2 раза
    m_plotWidget->setHorizScale(m_plotWidget->getHorizScale() * 1.2);
}

void OscilloscopeForm::onHorizZoomOut()
{
    m_plotWidget->setHorizScale(m_plotWidget->getHorizScale() / 1.2);
}

void OscilloscopeForm::onDPosInc()
{
    setOptions(m_plotWidget->getDpos() + 1,
               m_plotWidget->getDneg(),
               m_plotWidget->getAcpShift());
}

void OscilloscopeForm::onDPosDec()
{
    setOptions(m_plotWidget->getDpos() - 1,
               m_plotWidget->getDneg(),
               m_plotWidget->getAcpShift());
}

void OscilloscopeForm::onDNegInc()
{
    setOptions(m_plotWidget->getDpos(),
               m_plotWidget->getDneg() + 1,
               m_plotWidget->getAcpShift());
}

void OscilloscopeForm::onDNegDec()
{
    setOptions(m_plotWidget->getDpos(),
               m_plotWidget->getDneg() - 1,
               m_plotWidget->getAcpShift());
}

void OscilloscopeForm::onAcpShiftInc()
{
    setOptions(m_plotWidget->getDpos(),
               m_plotWidget->getDneg(),
               m_plotWidget->getAcpShift() + 1);
}

void OscilloscopeForm::onAcpShiftDec()
{
    setOptions(m_plotWidget->getDpos(),
               m_plotWidget->getDneg(),
               m_plotWidget->getAcpShift() - 1);
}

// Обработчик прокрутки: меняем начальный индекс отображаемой области
void OscilloscopeForm::onScrollChanged(int value)
{
    m_plotWidget->setStartIndex(value);
}

// Обновить текстовые метки на основе текущих параметров виджета графика
void OscilloscopeForm::updateUIFromParams()
{
    m_lblDPos->setText(QString::number(m_plotWidget->getDpos()));
    m_lblDNeg->setText(QString::number(m_plotWidget->getDneg()));
    m_lblAcpShift->setText(QString::number(m_plotWidget->getAcpShift()));
    m_lblVertScale->setText(QString("V scale: %1").arg(m_plotWidget->getVertScale(), 0, 'f', 2));
    m_lblHorizScale->setText(QString("H scale: %1").arg(m_plotWidget->getHorizScale(), 0, 'f', 2));
}