#include "plotwidget.h"
#include <QPainter>
#include <QPen>
#include <QMouseEvent>
#include <algorithm>
#include <cmath>
#include <limits>

PlotWidget::PlotWidget(QWidget *parent) : QWidget(parent)
{
    setMinimumSize(400, 300);      // минимальные размеры
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);   // фон будет белым
}

// Задать новые данные и шаг
void PlotWidget::setData(const QVector<double>& data, int stepMs)
{
    m_data = data;
    m_stepMs = stepMs;
    m_startIndex = 0;              // сброс прокрутки
    update();                      // перерисовать
    emit paramsChanged();          // оповестить об изменении
}

void PlotWidget::setStepMs(int stepMs)
{
    m_stepMs = stepMs;
    update();
    emit paramsChanged();
}

void PlotWidget::setDpos(int dpos)
{
    m_dpos = dpos;
    update();
    emit paramsChanged();
}

void PlotWidget::setDneg(int dneg)
{
    m_dneg = dneg;
    update();
    emit paramsChanged();
}

void PlotWidget::setAcpShift(int shift)
{
    m_acpShift = shift;
    update();
    emit paramsChanged();
}

void PlotWidget::setVertScale(double scale)
{
    m_vertScale = scale;
    update();
    emit paramsChanged();
}

void PlotWidget::setHorizScale(double scale)
{
    if (scale < 0.1) scale = 0.1;   // защита от слишком сильного сжатия
    m_horizScale = scale;
    // После изменения горизонтального масштаба количество видимых точек меняется,
    // корректируем начальный индекс, чтобы не выйти за границы
    int visible = getVisiblePoints();
    if (m_startIndex + visible > static_cast<int>(m_data.size()))
        m_startIndex = std::max(0, static_cast<int>(m_data.size()) - visible);
    update();
    emit paramsChanged();
}

void PlotWidget::setStartIndex(int index)
{
    int visible = getVisiblePoints();
    if (visible <= 0) return;
    // Ограничиваем индекс допустимыми пределами
    if (index < 0) index = 0;
    if (index + visible > static_cast<int>(m_data.size()))
        index = std::max(0, static_cast<int>(m_data.size()) - visible);
    m_startIndex = index;
    update();
    emit paramsChanged();
}

// Количество точек, которое помещается в видимую область по горизонтали
int PlotWidget::getVisiblePoints() const
{
    if (m_data.isEmpty()) return 0;
    int total = static_cast<int>(m_data.size());
    // Чем больше m_horizScale, тем меньше точек видно (растяжение)
    int vis = static_cast<int>(total / m_horizScale);
    if (vis < 1) vis = 1;
    if (vis > total) vis = total;
    return vis;
}

// Область, отведённая под график (с отступами для осей и подписей)
QRect PlotWidget::getPlotRect() const
{
    QRect rect = contentsRect();
    int left = 50, right = 30, top = 20, bottom = 30;
    return rect.adjusted(left, top, -right, -bottom);
}

// Преобразование индекса точки в X-координату (линейная интерполяция)
double PlotWidget::transformX(int index) const
{
    QRect rect = getPlotRect();
    int visible = getVisiblePoints();
    if (visible <= 0) return rect.left();
    double t = static_cast<double>(index - m_startIndex) / visible;
    return rect.left() + t * rect.width();
}

// Преобразование значения Y (амплитуды) в координату Y экрана
double PlotWidget::transformY(double value, double yMin, double yMax) const
{
    QRect rect = getPlotRect();
    if (yMax <= yMin) return rect.center().y();
    double t = (value - yMin) / (yMax - yMin);
    return rect.bottom() - t * rect.height();  // Y растёт вниз
}

// Вычисление минимального и максимального значения Y для текущей видимой области
void PlotWidget::computeYRange(double &yMin, double &yMax) const
{
    yMin =  std::numeric_limits<double>::max();
    yMax = -std::numeric_limits<double>::max();

    int start = m_startIndex;
    int end = std::min(static_cast<int>(m_startIndex + getVisiblePoints()),
                       static_cast<int>(m_data.size()));
    // Проходим по всем видимым точкам, учитывая вертикальный масштаб
    for (int i = start; i < end; ++i) {
        double val = m_data[i] * m_vertScale;
        if (val < yMin) yMin = val;
        if (val > yMax) yMax = val;
    }
    // Также учитываем опорные линии DPos и DNeg (они тоже могут выходить за пределы данных)
    double dposScaled = m_dpos * m_vertScale;
    double dnegScaled = m_dneg * m_vertScale;
    yMin = std::min({yMin, dposScaled, dnegScaled});
    yMax = std::max({yMax, dposScaled, dnegScaled});

    // Добавляем небольшой отступ (10% от диапазона) для красивого отображения
    double margin = (yMax - yMin) * 0.1;
    if (margin == 0) margin = 1.0;  // если все значения равны
    yMin -= margin;
    yMax += margin;
}

// Событие отрисовки
void PlotWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    if (m_data.isEmpty()) {
        QPainter painter(this);
        painter.fillRect(rect(), Qt::white);
        painter.drawText(rect(), Qt::AlignCenter, "No data");
        return;
    }

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing); // сглаживание

    QRect plotRect = getPlotRect();
    if (plotRect.width() <= 0 || plotRect.height() <= 0)
        return;

    // Заливаем фон области графика белым и рисуем рамку
    painter.fillRect(plotRect, Qt::white);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawRect(plotRect);

    // Вычисляем диапазон Y для текущей видимой области
    double yMin, yMax;
    computeYRange(yMin, yMax);

    // Рисуем сам сигнал (синяя линия)
    painter.setPen(QPen(Qt::blue, 2));
    int visible = getVisiblePoints();
    int start = m_startIndex;
    int end = std::min(start + visible, static_cast<int>(m_data.size()));

    QPolygonF polyline;
    for (int i = start; i < end; ++i) {
        double x = transformX(i);
        double val = m_data[i] * m_vertScale + m_acpShift;   // применяем масштаб и сдвиг
        double y = transformY(val, yMin, yMax);
        polyline << QPointF(x, y);
    }
    painter.drawPolyline(polyline);

    // Рисуем опорные линии DPos и DNeg (красные пунктиры) с учётом сдвига AcpShift
    QPen dPen(Qt::red, 2, Qt::DashLine);
    painter.setPen(dPen);
    double dposScaled = m_dpos * m_vertScale + m_acpShift;
    double dnegScaled = m_dneg * m_vertScale + m_acpShift;
    int yPos = static_cast<int>(transformY(dposScaled, yMin, yMax));
    int yNeg = static_cast<int>(transformY(dnegScaled, yMin, yMax));
    painter.drawLine(plotRect.left(), yPos, plotRect.right(), yPos);
    painter.drawLine(plotRect.left(), yNeg, plotRect.right(), yNeg);

    // Подписи осей: время в начале и конце видимого интервала
    painter.setPen(Qt::black);
    int visibleTimeMs = static_cast<int>(getVisiblePoints() * m_stepMs / m_horizScale);
    int startTimeMs = m_startIndex * m_stepMs;
    painter.drawText(plotRect.left(), plotRect.bottom() + 15,
                     QString("t = %1 ms").arg(startTimeMs));
    painter.drawText(plotRect.right() - 60, plotRect.bottom() + 15,
                     QString("+%1 ms").arg(visibleTimeMs));
    // Подписи максимального и минимального значения Y слева
    painter.drawText(plotRect.left() - 40, plotRect.top() + 10,
                     QString::number(yMax, 'f', 1));
    painter.drawText(plotRect.left() - 40, plotRect.bottom() - 5,
                     QString::number(yMin, 'f', 1));
}

// --- Обработка мыши для перетаскивания опорных линий ---

void PlotWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() != Qt::LeftButton) return;

    QRect plotRect = getPlotRect();
    if (!plotRect.contains(event->pos())) return;

    double yMin, yMax;
    computeYRange(yMin, yMax);

    int clickY = event->pos().y();
    double dposVal = m_dpos * m_vertScale + m_acpShift;
    double dnegVal = m_dneg * m_vertScale + m_acpShift;
    int yPos = valueToY(dposVal, yMin, yMax);
    int yNeg = valueToY(dnegVal, yMin, yMax);

    // Если кликнули близко к линии DPos (5 пикселей) – начинаем перетаскивание DPos
    if (std::abs(clickY - yPos) <= 5) {
        m_dragMode = DragDPos;
        m_dragStartY = clickY;
        m_originalValue = m_dpos;
        setCursor(Qt::SizeVerCursor);
        event->accept();
        return;
    }
    // Аналогично для DNeg
    if (std::abs(clickY - yNeg) <= 5) {
        m_dragMode = DragDNeg;
        m_dragStartY = clickY;
        m_originalValue = m_dneg;
        setCursor(Qt::SizeVerCursor);
        event->accept();
        return;
    }
}

void PlotWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (m_dragMode == NoDrag) return;

    double yMin, yMax;
    computeYRange(yMin, yMax);
    int currentY = event->pos().y();
    int deltaY = currentY - m_dragStartY;

    // Вычисляем, сколько единиц амплитуды приходится на один пиксель
    double yRangePixels = valueToY(yMin, yMin, yMax) - valueToY(yMax, yMin, yMax);
    double valuePerPixel = (yMax - yMin) / yRangePixels;
    double deltaValue = -deltaY * valuePerPixel / m_vertScale;  // знак минус, так как Y оси направлена вниз

    if (m_dragMode == DragDPos) {
        setDpos(qRound(m_originalValue + deltaValue));
    } else if (m_dragMode == DragDNeg) {
        setDneg(qRound(m_originalValue + deltaValue));
    }
    update(); // перерисовываем с новыми линиями
}

void PlotWidget::mouseReleaseEvent(QMouseEvent *event)
{
    if (m_dragMode != NoDrag) {
        m_dragMode = NoDrag;
        setCursor(Qt::ArrowCursor);
        event->accept();
    }
}

// Вспомогательные методы для преобразования Y-координаты <-> значение амплитуды
double PlotWidget::yToValue(int y, double yMin, double yMax) const
{
    QRect rect = getPlotRect();
    double t = static_cast<double>(rect.bottom() - y) / rect.height();
    return yMin + t * (yMax - yMin);
}

int PlotWidget::valueToY(double value, double yMin, double yMax) const
{
    QRect rect = getPlotRect();
    double t = (value - yMin) / (yMax - yMin);
    return rect.bottom() - static_cast<int>(t * rect.height());
}