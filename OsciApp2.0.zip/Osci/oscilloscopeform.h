#ifndef OSCILLOSCOPEFORM_H
#define OSCILLOSCOPEFORM_H

#include <QWidget>
#include <QVector>

// Управление экспортом/импортом символов в зависимости от того,
// собираем ли мы библиотеку (OSCILLOSCOPE_LIBRARY) или используем её.
#ifdef OSCILLOSCOPE_LIBRARY
#define OSCILLOSCOPE_EXPORT Q_DECL_EXPORT
#else
#define OSCILLOSCOPE_EXPORT Q_DECL_IMPORT
#endif

class PlotWidget;      // виджет для отрисовки графика
class QScrollBar;      // горизонтальная полоса прокрутки
class QPushButton;     // кнопки управления
class QLabel;          // надписи для отображения параметров

// Главный класс формы осциллографа, доступный извне (экспортируется)
class OSCILLOSCOPE_EXPORT OscilloscopeForm : public QWidget
{
    Q_OBJECT

public:
    // Конструктор: принимает начальные значения DPos, DNeg, AcpShift
    explicit OscilloscopeForm(QWidget *parent = nullptr,
                              int initDPos = 0, int initDNeg = 0, int initAcpShift = 0);
    ~OscilloscopeForm();

    // Передать массив данных для отображения и шаг дискретизации (мс)
    void sendData(const QVector<double>& data, int stepMs);
    // Получить текущие настройки канала
    void getOptions(int &dPos, int &dNeg, int &acpShift) const;
    // Установить настройки канала
    void setOptions(int dPos, int dNeg, int acpShift);

private slots:
    // Обработчики кнопок
    void onHorizZoomIn();      // горизонтальное увеличение масштаба
    void onHorizZoomOut();     // горизонтальное уменьшение
    void onDPosInc();          // увеличить DPos
    void onDPosDec();          // уменьшить DPos
    void onDNegInc();
    void onDNegDec();
    void onAcpShiftInc();      // увеличить сдвиг канала
    void onAcpShiftDec();
    void onScrollChanged(int value);    // скролл графика
    void updateUIFromParams();          // обновить текстовые метки

private:
    PlotWidget   *m_plotWidget;      // виджет с графиком
    QScrollBar   *m_scrollBar;       // полоса прокрутки по горизонтали
    QPushButton  *m_btnHorizZoomIn, *m_btnHorizZoomOut;
    QPushButton  *m_btnDPosInc, *m_btnDPosDec;
    QPushButton  *m_btnDNegInc, *m_btnDNegDec;
    QPushButton  *m_btnAcpInc, *m_btnAcpDec;
    QLabel       *m_lblDPos, *m_lblDNeg, *m_lblAcpShift;
    QLabel       *m_lblVertScale, *m_lblHorizScale;
};

// Экспортируемые C-функции для использования из любого языка/приложения
extern "C" {
// Создать окно осциллографа с заданными параметрами канала и геометрией
OSCILLOSCOPE_EXPORT void CreateOscilloscope(int DPos, int DNeg, int AcpShift,
                                            int Left, int Top, int Width, int Height);
// Отправить данные (массив double) и шаг в миллисекундах
OSCILLOSCOPE_EXPORT void SendData(int NumberOfPoints, double* Bufer, int Step);
// Получить текущие настройки канала
OSCILLOSCOPE_EXPORT void GetChannelOptions(int& DPos, int& DNeg, int& AcpShift);
// Установить настройки канала
OSCILLOSCOPE_EXPORT void SetOptions(int DPos, int DNeg, int AcpShift);
}

#endif // OSCILLOSCOPEFORM_H