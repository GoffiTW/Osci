#ifndef OSCILLOSCOPEFORM_H
#define OSCILLOSCOPEFORM_H

#include <QWidget>
#include <QVector>

#ifdef OSCILLOSCOPE_LIBRARY
#define OSCILLOSCOPE_EXPORT Q_DECL_EXPORT
#else
#define OSCILLOSCOPE_EXPORT Q_DECL_IMPORT
#endif

class PlotWidget;
class QScrollBar;
class QPushButton;
class QLabel;

class OSCILLOSCOPE_EXPORT OscilloscopeForm : public QWidget
{
    Q_OBJECT
public:
    explicit OscilloscopeForm(QWidget *parent = nullptr,
                              int initDPos = 0, int initDNeg = 0, int initAcpShift = 0);
    ~OscilloscopeForm();

    void sendData(const QVector<double>& data, int stepMs);
    void getOptions(int &dPos, int &dNeg, int &acpShift) const;
    void setOptions(int dPos, int dNeg, int acpShift);

private slots:
    void onHorizZoomIn();
    void onHorizZoomOut();
    void onDPosInc();
    void onDPosDec();
    void onDNegInc();
    void onDNegDec();
    void onAcpShiftInc();
    void onAcpShiftDec();
    void onScrollChanged(int value);
    void updateUIFromParams();

private:
    PlotWidget *m_plotWidget;
    QScrollBar *m_scrollBar;

    QPushButton *m_btnHorizZoomIn, *m_btnHorizZoomOut;
    QPushButton *m_btnDPosInc, *m_btnDPosDec;
    QPushButton *m_btnDNegInc, *m_btnDNegDec;
    QPushButton *m_btnAcpInc, *m_btnAcpDec;
    QLabel *m_lblDPos, *m_lblDNeg, *m_lblAcpShift, *m_lblVertScale, *m_lblHorizScale;
};

extern "C" {
OSCILLOSCOPE_EXPORT void CreateOscilloscope(int DPos, int DNeg, int AcpShift,
                                            int Left, int Top, int Width, int Height);
OSCILLOSCOPE_EXPORT void SendData(int NumberOfPoints, double* Bufer, int Step);
OSCILLOSCOPE_EXPORT void GetChannelOptions(int& DPos, int& DNeg, int& AcpShift);
OSCILLOSCOPE_EXPORT void SetOptions(int DPos, int DNeg, int AcpShift);
}

#endif // OSCILLOSCOPEFORM_H