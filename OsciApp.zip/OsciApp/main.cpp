#include <QApplication>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include "mainwindow.h"

static QVector<double> g_dataBuffer;
static int TOTAL_POINTS = 0;
static const int MAX_POINTS = 2000;
static const int STEP_MS = 10;
static bool dataGenerated = false;

double noise() {
    return (rand() % 11) - 5;
}

void generatePacket(QVector<double>& buffer, double amplitude, const QVector<int>& bits, int samplesPerBit) {
    for (int bit : bits) {
        double level = (bit == 1) ? amplitude : -amplitude;
        for (int j = 0; j < samplesPerBit; ++j) {
            buffer.append(level + noise() * 0.5);
        }
    }
}

void generateData()
{
    if (dataGenerated) return;
    srand(static_cast<unsigned>(time(nullptr)));

    TOTAL_POINTS = 500 + rand() % (MAX_POINTS - 500 + 1);
    g_dataBuffer.clear();
    g_dataBuffer.reserve(TOTAL_POINTS);

    // начальный шум
    int initialNoise = 50 + rand() % 100;
    for (int i = 0; i < initialNoise && g_dataBuffer.size() < TOTAL_POINTS; ++i) {
        g_dataBuffer.append(noise());
    }

    // пакет битов
    int numBits = 10 + rand() % 21;
    QVector<int> bits;
    for (int i = 0; i < numBits; ++i) bits.append(rand() % 2);
    int samplesPerBit = 10;
    double signalAmplitude = 20.0;
    generatePacket(g_dataBuffer, signalAmplitude, bits, samplesPerBit);

    // остаток шумом
    if (g_dataBuffer.size() < TOTAL_POINTS) {
        int remaining = TOTAL_POINTS - g_dataBuffer.size();
        for (int i = 0; i < remaining; ++i) g_dataBuffer.append(noise());
    } else {
        g_dataBuffer.resize(TOTAL_POINTS);
    }

    dataGenerated = true;
}

QVector<double>& getDataBuffer() { return g_dataBuffer; }
int getTotalPoints() { return TOTAL_POINTS; }
int getStepMs() { return STEP_MS; }

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    generateData();
    MainWindow w;
    w.show();
    return a.exec();
}