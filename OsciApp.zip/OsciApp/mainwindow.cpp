#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "oscilloscopeform.h"

extern QVector<double>& getDataBuffer();
extern int getTotalPoints();
extern int getStepMs();

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->btnCreateOsc, &QPushButton::clicked, this, &MainWindow::onCreateOscilloscope);
    connect(ui->btnSendData, &QPushButton::clicked, this, &MainWindow::onSendData);
    connect(ui->btnGetOptions, &QPushButton::clicked, this, &MainWindow::onGetOptions);
    connect(ui->btnSetOptions, &QPushButton::clicked, this, &MainWindow::onSetOptions);
    ui->lblStatus->setText(QString("Данные сгенерированы: %1 точек").arg(getTotalPoints()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onCreateOscilloscope()
{
    int dPos = ui->spinDPos->value();
    int dNeg = ui->spinDNeg->value();
    int acpShift = ui->spinAcpShift->value();
    CreateOscilloscope(dPos, dNeg, acpShift, 100, 100, 800, 600);
    ui->lblStatus->setText("Осциллограф создан");
}

void MainWindow::onSendData()
{
    QVector<double>& data = getDataBuffer();
    if (data.isEmpty()) {
        QMessageBox::warning(this, "Предупреждение", "Нет данных для отправки");
        return;
    }
    SendData(data.size(), data.data(), getStepMs());
    ui->lblStatus->setText(QString("Данные отправлены: %1 точек, шаг %2 мс")
                               .arg(data.size()).arg(getStepMs()));
}

void MainWindow::onGetOptions()
{
    int dPos, dNeg, acpShift;
    GetChannelOptions(dPos, dNeg, acpShift);
    ui->spinDPos->setValue(dPos);
    ui->spinDNeg->setValue(dNeg);
    ui->spinAcpShift->setValue(acpShift);
    QString message = QString("DPos: %1\nDNeg: %2\nAcpShift: %3")
                          .arg(dPos).arg(dNeg).arg(acpShift);
    QMessageBox::information(this, "Channel Options", message);
    ui->lblStatus->setText("Настройки получены из DLL");
}

void MainWindow::onSetOptions()
{
    int dPos = ui->spinDPos->value();
    int dNeg = ui->spinDNeg->value();
    int acpShift = ui->spinAcpShift->value();
    SetOptions(dPos, dNeg, acpShift);
    ui->lblStatus->setText(QString("Настройки отправлены в DLL: DPos=%1, DNeg=%2, AcpShift=%3")
                               .arg(dPos).arg(dNeg).arg(acpShift));
}