#ifndef APPDATA_H
#define APPDATA_H

#include <QVector>

extern QVector<double> g_dataBuffer;
extern const int TOTAL_POINTS;
extern const int STEP_MS;

#endif // APPDATA_H